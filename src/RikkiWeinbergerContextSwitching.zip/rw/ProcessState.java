package rw;

public enum ProcessState {READY, BLOCKED, SUSPENDED_READY,
	                      SUSPENDED_BLOCKED, FINISHED}
